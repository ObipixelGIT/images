# DomainTrust MCP

A free OSINT Website Safety MCP for passive, one domain at a time trust reports.

DomainTrust MCP checks public website and domain signals and returns a plain English Website Trust Report with a risk rating and suggested fixes.

## What it checks

- Domain WHOIS age and expiry, where available.
- DNS records, including A, AAAA, MX, NS, TXT and CAA.
- SSL certificate issuer, expiry and subject alternative names.
- Email security records, including SPF, DMARC and common DKIM selectors.
- Exposed subdomains from crt.sh certificate transparency data.
- Website technology hints from headers and page source.
- HTTP security headers.
- Basic reputation-style signals, such as HTTPS, redirects, age, certificate health and security posture.

## What it does not do

This is a passive OSINT tool. It does not exploit, brute force, fuzz, scan ports, bypass access controls, or test vulnerabilities.

## Install

```bash
cd domaintrust-mcp
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run locally

```bash
python -m domaintrust_mcp.server
```

## Add to Claude Desktop

Edit your Claude Desktop config file and add this server.

macOS path:

```text
~/Library/Application Support/Claude/claude_desktop_config.json
```

Microsoft path:
You will need to get that from the folder you using for Claude

Example config:

```json
{
  "mcpServers": {
    "domaintrust": {
      "command": "/absolute/path/to/domaintrust-mcp/.venv/bin/python",
      "args": ["-m", "domaintrust_mcp.server"],
      "cwd": "/absolute/path/to/domaintrust-mcp"
    }
  }
}
```

Restart Claude Desktop after saving the config.

## MCP tools

### `website_trust_report`

Creates a full trust report for a single domain, website URL, or company-style domain input.

Example prompt:

```text
Use DomainTrust MCP to produce a website trust report for example.com.
```

### `quick_domain_check`

Returns a shorter plain-English summary.

Example prompt:

```text
Use DomainTrust MCP to quickly check example.com.
```

## Direct CLI test

You can test the scanner without an MCP client.

```bash
python -m domaintrust_mcp.scanner example.com
```

## Files included

- `domaintrust_mcp/server.py`, MCP server and tools.
- `domaintrust_mcp/scanner.py`, passive OSINT collection and scoring.
- `examples/sample-report.md`, sample report structure.

## Suggested free offer wording

Give people one free domain report at a time. Ask for an email address only if you want to build a list, but keep the scan itself free.

