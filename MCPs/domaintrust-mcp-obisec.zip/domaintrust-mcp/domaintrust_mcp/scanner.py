from __future__ import annotations

import json
import re
import socket
import ssl
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import dns.resolver
import requests
from bs4 import BeautifulSoup

try:
    import whois  # type: ignore
except Exception:  # pragma: no cover
    whois = None

COMMON_DKIM_SELECTORS = ["default", "selector1", "selector2", "google", "k1", "mail", "smtp"]
USER_AGENT = "DomainTrustMCP/1.0 passive website safety reporter"
TIMEOUT = 8


def normalise_target(target: str) -> Tuple[str, str]:
    raw = target.strip().lower()
    raw = re.sub(r"^mailto:", "", raw)
    raw = re.sub(r"^[^@\s]+@", "", raw) if "@" in raw and "://" not in raw else raw
    if not raw.startswith(("http://", "https://")):
        url = "https://" + raw.strip("/")
    else:
        url = raw
    parsed = urlparse(url)
    domain = parsed.netloc.split(":")[0].strip().strip(".")
    if domain.startswith("www."):
        domain = domain[4:]
    return domain, url


def safe_dns(domain: str, record_type: str) -> List[str]:
    try:
        answers = dns.resolver.resolve(domain, record_type, lifetime=TIMEOUT)
        return [str(r).strip('"') for r in answers]
    except Exception:
        return []


def get_whois(domain: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"available": False, "created": None, "expires": None, "registrar": None, "age_days": None, "error": None}
    if whois is None:
        result["error"] = "python-whois not installed or unavailable"
        return result
    try:
        data = whois.whois(domain)
        created = data.creation_date[0] if isinstance(data.creation_date, list) else data.creation_date
        expires = data.expiration_date[0] if isinstance(data.expiration_date, list) else data.expiration_date
        result.update({
            "available": True,
            "created": created.isoformat() if hasattr(created, "isoformat") else str(created) if created else None,
            "expires": expires.isoformat() if hasattr(expires, "isoformat") else str(expires) if expires else None,
            "registrar": data.registrar if getattr(data, "registrar", None) else None,
        })
        if created and hasattr(created, "replace"):
            created_dt = created.replace(tzinfo=timezone.utc) if created.tzinfo is None else created
            result["age_days"] = max(0, (datetime.now(timezone.utc) - created_dt).days)
    except Exception as exc:
        result["error"] = str(exc)
    return result


def get_ssl(domain: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {"available": False, "issuer": None, "subject": None, "not_before": None, "not_after": None, "days_left": None, "san_count": 0, "error": None}
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
        not_after_raw = cert.get("notAfter")
        not_before_raw = cert.get("notBefore")
        not_after = datetime.strptime(not_after_raw, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc) if not_after_raw else None
        not_before = datetime.strptime(not_before_raw, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc) if not_before_raw else None
        issuer = ", ".join("=".join(x) for part in cert.get("issuer", []) for x in part)
        subject = ", ".join("=".join(x) for part in cert.get("subject", []) for x in part)
        san = cert.get("subjectAltName", [])
        result.update({
            "available": True,
            "issuer": issuer or None,
            "subject": subject or None,
            "not_before": not_before.isoformat() if not_before else None,
            "not_after": not_after.isoformat() if not_after else None,
            "days_left": (not_after - datetime.now(timezone.utc)).days if not_after else None,
            "san_count": len(san),
        })
    except Exception as exc:
        result["error"] = str(exc)
    return result


def fetch_site(url: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"available": False, "final_url": None, "status_code": None, "headers": {}, "title": None, "server": None, "powered_by": None, "error": None}
    try:
        r = requests.get(url, timeout=TIMEOUT, allow_redirects=True, headers={"User-Agent": USER_AGENT})
        soup = BeautifulSoup(r.text[:250000], "html.parser")
        title = soup.title.string.strip() if soup.title and soup.title.string else None
        out.update({
            "available": True,
            "final_url": r.url,
            "status_code": r.status_code,
            "headers": dict(r.headers),
            "title": title,
            "server": r.headers.get("Server"),
            "powered_by": r.headers.get("X-Powered-By"),
            "html_sample": r.text[:80000],
        })
    except Exception as exc:
        out["error"] = str(exc)
    return out


def email_security(domain: str) -> Dict[str, Any]:
    txt = safe_dns(domain, "TXT")
    spf = [x for x in txt if x.lower().startswith("v=spf1")]
    dmarc = safe_dns(f"_dmarc.{domain}", "TXT")
    dmarc_records = [x for x in dmarc if x.lower().startswith("v=dmarc1")]
    dkim: Dict[str, List[str]] = {}
    for selector in COMMON_DKIM_SELECTORS:
        records = safe_dns(f"{selector}._domainkey.{domain}", "TXT")
        hits = [x for x in records if "v=dkim1" in x.lower() or "p=" in x.lower()]
        if hits:
            dkim[selector] = hits
    return {"spf": spf, "dmarc": dmarc_records, "dkim_selectors_found": dkim}


def subdomains_from_crtsh(domain: str) -> Dict[str, Any]:
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        r = requests.get(url, timeout=TIMEOUT, headers={"User-Agent": USER_AGENT})
        if r.status_code != 200:
            return {"count": 0, "sample": [], "error": f"crt.sh returned {r.status_code}"}
        names = set()
        for row in r.json():
            name_value = row.get("name_value", "")
            for name in str(name_value).split("\n"):
                clean = name.strip().lower().lstrip("*.")
                if clean.endswith(domain):
                    names.add(clean)
        return {"count": len(names), "sample": sorted(names)[:60], "error": None}
    except Exception as exc:
        return {"count": 0, "sample": [], "error": str(exc)}


def detect_tech(site: Dict[str, Any]) -> List[str]:
    headers = {k.lower(): str(v) for k, v in site.get("headers", {}).items()}
    html = site.get("html_sample", "").lower()
    tech = set()
    server = headers.get("server")
    powered = headers.get("x-powered-by")
    if server:
        tech.add(f"Server header: {server}")
    if powered:
        tech.add(f"Powered by: {powered}")
    checks = {
        "WordPress": ["wp-content", "wp-includes"],
        "Shopify": ["cdn.shopify.com", "shopify"],
        "Squarespace": ["static1.squarespace.com", "squarespace"],
        "Wix": ["wixstatic", "x-wix"],
        "Cloudflare": ["cf-ray", "cloudflare"],
        "React": ["react", "__react"],
        "Next.js": ["_next/static", "next-data"],
        "Google Analytics": ["googletagmanager", "google-analytics"],
    }
    haystack = html + "\n" + "\n".join(f"{k}:{v}" for k, v in headers.items())
    for name, needles in checks.items():
        if any(n in haystack for n in needles):
            tech.add(name)
    return sorted(tech)


def security_headers(site: Dict[str, Any]) -> Dict[str, Any]:
    headers = {k.lower(): str(v) for k, v in site.get("headers", {}).items()}
    required = {
        "strict-transport-security": "HTTP Strict Transport Security",
        "content-security-policy": "Content Security Policy",
        "x-frame-options": "Clickjacking protection",
        "x-content-type-options": "MIME sniffing protection",
        "referrer-policy": "Referrer privacy policy",
        "permissions-policy": "Browser feature controls",
    }
    present = {name: headers.get(name) for name in required if headers.get(name)}
    missing = {name: label for name, label in required.items() if name not in present}
    return {"present": present, "missing": missing}


def score_report(report: Dict[str, Any]) -> Tuple[int, str, List[str], List[str]]:
    score = 100
    positives: List[str] = []
    fixes: List[str] = []
    ssl_info = report["ssl"]
    who = report["whois"]
    email = report["email_security"]
    headers = report["security_headers"]
    site = report["website"]

    if not site.get("available"):
        score -= 15; fixes.append("Check that the website loads cleanly over HTTPS.")
    elif str(site.get("final_url", "")).startswith("https://"):
        positives.append("The website loads over HTTPS.")
    else:
        score -= 15; fixes.append("Redirect all public website traffic to HTTPS.")

    if not ssl_info.get("available"):
        score -= 18; fixes.append("Install a valid TLS certificate.")
    else:
        positives.append("A TLS certificate is present.")
        days_left = ssl_info.get("days_left")
        if isinstance(days_left, int) and days_left < 21:
            score -= 12; fixes.append("Renew the TLS certificate soon.")

    age = who.get("age_days")
    if isinstance(age, int):
        if age < 180:
            score -= 12; fixes.append("Treat very new domains with extra care until more history exists.")
        elif age > 730:
            positives.append("The domain has more than two years of age history.")

    if not email.get("spf"):
        score -= 8; fixes.append("Add an SPF record to reduce spoofed email risk.")
    else:
        positives.append("SPF is present.")
    if not email.get("dmarc"):
        score -= 10; fixes.append("Add a DMARC record, ideally moving towards quarantine or reject.")
    else:
        positives.append("DMARC is present.")
    if not email.get("dkim_selectors_found"):
        score -= 5; fixes.append("Check that DKIM is enabled for the mail platform.")

    missing_headers = headers.get("missing", {})
    if missing_headers:
        score -= min(18, len(missing_headers) * 3)
        fixes.append("Add missing browser security headers: " + ", ".join(missing_headers.keys()) + ".")
    else:
        positives.append("Common browser security headers are present.")

    if report["subdomains"].get("count", 0) > 80:
        score -= 5; fixes.append("Review exposed subdomains and remove old test, staging or unused hosts.")

    score = max(0, min(100, score))
    rating = "Low risk" if score >= 80 else "Medium risk" if score >= 55 else "High risk"
    return score, rating, positives[:8], fixes[:10]


def markdown_report(report: Dict[str, Any]) -> str:
    lines = []
    lines.append(f"# Website Trust Report: {report['domain']}")
    lines.append("")
    lines.append(f"Risk rating: **{report['risk_rating']}**")
    lines.append(f"Trust score: **{report['trust_score']}/100**")
    lines.append("")
    lines.append("## Plain English Summary")
    summary = report.get("summary") or "The scan completed, but some public signals were unavailable. Review the details below."
    lines.append(summary)
    lines.append("")
    lines.append("## Suggested Fixes")
    for fix in report["suggested_fixes"]:
        lines.append(f"- {fix}")
    if not report["suggested_fixes"]:
        lines.append("- No urgent fixes found from these passive checks.")
    lines.append("")
    lines.append("## Key Positive Signals")
    for p in report["positive_signals"]:
        lines.append(f"- {p}")
    if not report["positive_signals"]:
        lines.append("- No strong positive signals were confirmed.")
    lines.append("")
    lines.append("## Findings")
    lines.append(f"- WHOIS: created {report['whois'].get('created')}, expires {report['whois'].get('expires')}, registrar {report['whois'].get('registrar')}.")
    lines.append(f"- SSL: issuer {report['ssl'].get('issuer')}, days left {report['ssl'].get('days_left')}.")
    lines.append(f"- DNS: A {len(report['dns'].get('A', []))}, MX {len(report['dns'].get('MX', []))}, NS {len(report['dns'].get('NS', []))}, TXT {len(report['dns'].get('TXT', []))} records found.")
    lines.append(f"- Email security: SPF {'yes' if report['email_security'].get('spf') else 'no'}, DMARC {'yes' if report['email_security'].get('dmarc') else 'no'}, DKIM selector hints {len(report['email_security'].get('dkim_selectors_found', {}))}.")
    lines.append(f"- Subdomains from certificate transparency: {report['subdomains'].get('count', 0)} found.")
    lines.append(f"- Technologies: {', '.join(report['technology_stack']) if report['technology_stack'] else 'No clear technology hints found.'}")
    lines.append(f"- Missing security headers: {', '.join(report['security_headers'].get('missing', {}).keys()) if report['security_headers'].get('missing') else 'None from the common list.'}")
    lines.append("")
    lines.append("## Passive OSINT Note")
    lines.append("This report uses public information only. It is a trust and hygiene review, not a penetration test.")
    return "\n".join(lines)


def scan_domain(target: str) -> Dict[str, Any]:
    domain, url = normalise_target(target)
    dns_data = {rtype: safe_dns(domain, rtype) for rtype in ["A", "AAAA", "MX", "NS", "TXT", "CAA"]}
    site = fetch_site(url)
    if not site.get("available") and url.startswith("https://"):
        site = fetch_site("http://" + domain)
    report: Dict[str, Any] = {
        "domain": domain,
        "input_url": url,
        "scanned_at": datetime.now(timezone.utc).isoformat(),
        "whois": get_whois(domain),
        "dns": dns_data,
        "ssl": get_ssl(domain),
        "website": {k: v for k, v in site.items() if k != "html_sample"},
        "email_security": email_security(domain),
        "subdomains": subdomains_from_crtsh(domain),
        "technology_stack": detect_tech(site),
        "security_headers": security_headers(site),
    }
    score, rating, positives, fixes = score_report(report)
    report["trust_score"] = score
    report["risk_rating"] = rating
    report["positive_signals"] = positives
    report["suggested_fixes"] = fixes
    report["summary"] = f"{domain} currently scores {score}/100 and is rated {rating.lower()}. The score is based on passive public signals including HTTPS, DNS, email authentication, certificate health, subdomain exposure and common browser security headers."
    report["markdown"] = markdown_report(report)
    return report


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m domaintrust_mcp.scanner example.com")
        raise SystemExit(1)
    print(markdown_report(scan_domain(sys.argv[1])))


if __name__ == "__main__":
    main()
