from __future__ import annotations

from typing import Any, Dict

from mcp.server.fastmcp import FastMCP

from .scanner import scan_domain

mcp = FastMCP("DomainTrust MCP")


@mcp.tool()
def website_trust_report(target: str) -> str:
    """Create a passive OSINT Website Trust Report for one domain or website URL.

    Use this for a plain-English trust report with a score, risk rating, public findings and suggested fixes.
    The tool is passive only and scans one domain at a time.
    """
    report = scan_domain(target)
    return report["markdown"]


@mcp.tool()
def quick_domain_check(target: str) -> Dict[str, Any]:
    """Run a short passive trust check for one domain or website URL."""
    report = scan_domain(target)
    return {
        "domain": report["domain"],
        "trust_score": report["trust_score"],
        "risk_rating": report["risk_rating"],
        "summary": report["summary"],
        "suggested_fixes": report["suggested_fixes"],
        "positive_signals": report["positive_signals"],
    }


if __name__ == "__main__":
    mcp.run()
