# Website Trust Report: example.com

Risk rating: **Low risk**
Trust score: **86/100**

## Plain English Summary

example.com currently scores 86/100 and is rated low risk. The score is based on passive public signals including HTTPS, DNS, email authentication, certificate health, subdomain exposure and common browser security headers.

## Suggested Fixes

- Add missing browser security headers where appropriate.
- Review exposed subdomains and remove unused hosts.

## Passive OSINT Note

This report uses public information only. It is a trust and hygiene review, not a penetration test.
